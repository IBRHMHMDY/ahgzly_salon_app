class BranchEntity {
  final int id;
  final String name;
  final String address;

  BranchEntity({required this.id, required this.name, required this.address});
}
