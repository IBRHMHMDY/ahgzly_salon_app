class EmployeeEntity {
  final int id;
  final String name;

  EmployeeEntity({required this.id, required this.name});
}
