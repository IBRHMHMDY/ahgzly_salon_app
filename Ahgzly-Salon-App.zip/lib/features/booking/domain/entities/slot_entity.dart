class SlotEntity {
  final String time; // مثال: "03:30"
  final bool isAvailable;

  SlotEntity({required this.time, required this.isAvailable});
}
